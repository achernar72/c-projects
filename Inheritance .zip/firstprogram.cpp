// Example program
#include <iostream>
#include <string>

using namespace std;
class Information{
    private:
     char name[20];
     int age;
    
    public:
    void dataSet(){
        cout<< "Enter the name:";
        cin>>name;
        cout<<"Enter the Age";
        cin>>age;
    
    }
    void printData(){
        cout << "\n \n name:" <<name;
        cout << "\n age:" <<age;
    
    }
};
class Details : public Information
{
    
    private: 
        char job[20];
        int salary;
    public:
        void selfDetails(){
            dataSet();
            cout<<"enter the job position:";
            cin>>job;
            cout<<"enter the salary:";
            cin>>salary;
    }
        void printDetails(){
            printData();
            cout<< "\n job:"<< job;
            cout<< "\n salary:"<<salary;
        }
};

int main()
{
      Details a;
      a.selfDetails();
      a.printDetails();

}